<?php
// /forum/new_thread.php — robust + fill ALL required legacy columns
require_once __DIR__ . '/_common.php';
require_member();

/* ---- Input & forum lookup ---- */
$forum_id = (int)($_GET['forum_id'] ?? 0);
if ($forum_id <= 0) { http_response_code(400); exit('Invalid forum'); }

$st = $pdo->prepare("SELECT id, name, is_container, admin_only FROM forums WHERE id = ?");
$st->execute([$forum_id]);
$forum = $st->fetch(PDO::FETCH_ASSOC);
if (!$forum) { http_response_code(404); exit('Forum not found'); }

require_forum_access($forum);
if (!empty($forum['is_container'])) { http_response_code(400); exit('Cannot post in a category. Choose a subforum.'); }

/* ---- schema helpers ---- */
function colmap(PDO $pdo, string $table): array {
  // returns ['name' => ['Null'=>'YES/NO','Default'=>..., 'Type'=>...], ...] lowercased
  $out = [];
  $q = $pdo->query("SHOW COLUMNS FROM {$table}");
  if ($q) foreach ($q->fetchAll(PDO::FETCH_ASSOC) as $r) $out[strtolower($r['Field'])] = $r;
  return $out;
}
function has(array $m, string $c): bool { return isset($m[strtolower($c)]); }
function required(array $m, string $c): bool {
  $c = strtolower($c);
  if (!isset($m[$c])) return false;
  // required if Null='NO' and Default is NULL
  return (strtoupper((string)$m[$c]['Null']) === 'NO') && ($m[$c]['Default'] === null);
}
function u_id(): int { return (int)($_SESSION['user_id'] ?? 0); }
function u_name(): string { return (string)($_SESSION['username'] ?? ''); }

/* ---- form handling ---- */
$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if (!csrf_ok($_POST['csrf'] ?? '')) {
    $errors[] = "Security token invalid. Please reload.";
  } else {
    $title = trim((string)($_POST['title'] ?? ''));
    
    
    $body = sanitize_html_basic($body);

    
    $body  = trim((string)($_POST['body'] ?? ''));

    if ($title === '' || $body === '') $errors[] = "Title and message are required.";
    if (mb_strlen($title) > 200) $errors[] = "Title is too long (max 200).";

    if (!$errors) {
      try {
        $pdo->beginTransaction();

        /* Insert thread (minimal) */
        $tcols = colmap($pdo,'threads');
        $thCols   = ['forum_id','user_id','title'];
        $thParams = [$forum_id, u_id(), $title];

        $sql = "INSERT INTO threads (" . implode(',', $thCols);
        if (has($tcols,'created_at'))   $sql .= ",created_at";
        if (has($tcols,'last_post_at')) $sql .= ",last_post_at";
        $sql .= ") VALUES (" . rtrim(str_repeat('?,', count($thParams)), ',');
        if (has($tcols,'created_at'))   $sql .= ",NOW()";
        if (has($tcols,'last_post_at')) $sql .= ",NOW()";
        $sql .= ")";

        $insT = $pdo->prepare($sql);
        $insT->execute($thParams);
        $thread_id = (int)$pdo->lastInsertId();
        if ($thread_id <= 0) throw new RuntimeException("No thread id returned");

        /* Insert first post — fill ALL required legacy cols */
        $pmap   = colmap($pdo,'posts');
        $cols   = [];
        $params = [];

        // Linkage (set BOTH if present & required)
        if (has($pmap,'thread_id')) { $cols[]='thread_id'; $params[]=$thread_id; }
        if (has($pmap,'topic_id'))  { $cols[]='topic_id';  $params[]=$thread_id; } // legacy twin

        // User id variants (pick one; but if multiples are REQUIRED, fill them too)
        $uidValue = u_id();
        foreach (['user_id','author_id','poster_id'] as $c) {
          if (has($pmap,$c) && required($pmap,$c)) { $cols[]=$c; $params[]=$uidValue; }
        }
        // If none required but at least one exists, set the first available:
        if (!array_intersect(['user_id','author_id','poster_id'], array_map('strtolower',$cols))) {
          foreach (['user_id','author_id','poster_id'] as $c) {
            if (has($pmap,$c)) { $cols[]=$c; $params[]=$uidValue; break; }
          }
        }

        // Author display (fill all that are REQUIRED; else set first available)
        $uname = u_name();
        $authorSet = false;
        foreach (['author','poster','username'] as $c) {
          if (has($pmap,$c) && required($pmap,$c)) { $cols[]=$c; $params[]=$uname; $authorSet = true; }
        }
        if (!$authorSet) {
          foreach (['author','poster','username'] as $c) {
            if (has($pmap,$c)) { $cols[]=$c; $params[]=$uname; break; }
          }
        }

        // Subject/title on posts (some schemas require it)
        $subjSet = false;
        foreach (['subject','post_title'] as $c) {
          if (has($pmap,$c) && required($pmap,$c)) { $cols[]=$c; $params[]=$title; $subjSet = true; }
        }
        if (!$subjSet) {
          foreach (['subject','post_title'] as $c) {
            if (has($pmap,$c) && !in_array($c, $cols, true)) { $cols[]=$c; $params[]=$title; break; }
          }
        }

        // Body/content: fill ALL body-like columns that are REQUIRED; otherwise set the first available
        $bodyCols = ['body','content','message','post_text','text'];
        $anyRequiredBody = false;
        foreach ($bodyCols as $c) {
          if (has($pmap,$c) && required($pmap,$c)) { $cols[]=$c; $params[]=$body; $anyRequiredBody = true; }
        }
        if (!$anyRequiredBody) {
          foreach ($bodyCols as $c) {
            if (has($pmap,$c)) { $cols[]=$c; $params[]=$body; break; }
          }
        }

        // Optional metadata
        $ip = $_SERVER['REMOTE_ADDR'] ?? '';
        if (has($pmap,'ip'))         { $cols[]='ip';         $params[]=$ip; }
        if (has($pmap,'ip_address')) { $cols[]='ip_address'; $params[]=$ip; }
        if (has($pmap,'user_agent')) { $cols[]='user_agent'; $params[]=(string)($_SERVER['HTTP_USER_AGENT'] ?? ''); }

        // Timestamps (append NOW() for any that exist)
        $nowCols = [];
        foreach (['created_at','post_time','posted_at','created'] as $ts) if (has($pmap,$ts)) $nowCols[]=$ts;

        // Build insert
        $sqlCols = implode(',', $cols) . (empty($nowCols) ? '' : ',' . implode(',', $nowCols));
        $place   = rtrim(str_repeat('?,', count($params)), ',');
        $sqlVals = $place . (empty($nowCols) ? '' : ',' . implode(',', array_fill(0, count($nowCols), 'NOW()')));

        $insP = $pdo->prepare("INSERT INTO posts ($sqlCols) VALUES ($sqlVals)");
        $insP->execute($params);

        // Touch thread last_post_at if exists
        if (has($tcols,'last_post_at')) {
          $pdo->prepare("UPDATE threads SET last_post_at = NOW() WHERE id = ?")->execute([$thread_id]);
        }

        $pdo->commit();
        header('Location: /forum/thread.php?id=' . $thread_id);
        exit;
      } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        $errors[] = "Failed to create thread: " . $e->getMessage();
      }
    }
  }
}

forum_header('New Thread in ' . $forum['name']);
?>
<style>
  .card{background:#fff;border:1px solid #ddd;border-radius:12px;padding:16px;margin:16px 0}
  .btn{display:inline-block;padding:8px 12px;border:1px solid #888;border-radius:8px;background:#f3f3f3;color:#111;text-decoration:none}
  .muted{color:#666}
  .field{margin:8px 0}
  input[type=text], textarea{width:100%;padding:10px;border:1px solid #ccc;border-radius:8px}
  textarea{min-height:180px}
</style>

<div class="card" style="max-width:840px;">
  <?php foreach ($errors as $e): ?>
    <div style="color:#a33;margin-bottom:8px;"><?= e($e) ?></div>
  <?php endforeach; ?>

  <form method="post" autocomplete="off">
    <?php csrf_input(); ?>
    <div class="field">
      <label>Title</label>
      <input type="text" name="title" maxlength="200" required>
    </div>
    <div class="field">
      <label>Message</label>
      <textarea name="body" required></textarea>
      <div class="muted">Tip: Use [b], [i], [u], and paste http(s):// links. Line breaks are kept.</div>
    </div>
    <div class="field">
      <button class="btn" type="submit">Post Thread</button>
      <a class="btn" href="/forum/forum.php?id=<?= (int)$forum_id ?>">Cancel</a>
    </div>
  </form>
</div>

<?php forum_footer(); ?>