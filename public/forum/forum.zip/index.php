<?php
require_once __DIR__ . '/_common.php';
require_member();

/* Fetch all forums; group into containers (categories) + subforums */
$all = $pdo->query("SELECT id, name, parent_id, is_container, admin_only FROM forums ORDER BY parent_id IS NULL DESC, name ASC")->fetchAll(PDO::FETCH_ASSOC);

$cats = []; $children = [];
foreach ($all as $f) {
  if (!empty($f['is_container'])) $cats[] = $f; else $children[] = $f;
}
$byParent = [];
foreach ($children as $ch) {
  $byParent[(int)($ch['parent_id'] ?? 0)][] = $ch;
}

forum_header('Forums');
?>
<style>
  .card{background:#fff;border:1px solid #ddd;border-radius:12px;padding:16px;margin:16px 0}
  .muted{color:#666}
  .sublist{margin:10px 0 0 18px;padding:0}
  .sublist li{margin:6px 0}
  .pill{display:inline-block;padding:2px 8px;border-radius:999px;border:1px solid #aaa;background:#fafafa;font-size:12px;margin-left:6px}
</style>

<?php if (empty($cats) && empty($children)): ?>
  <div class="card">No forums yet.</div>
<?php endif; ?>

<?php foreach ($cats as $cat): if (!can_view_forum($cat)) continue; ?>
  <div class="card">
    <h2 style="margin:0 0 8px;">
      <?= e($cat['name']) ?>
      <?php if (!empty($cat['admin_only'])): ?><span class="pill">Staff</span><?php endif; ?>
    </h2>
    <?php $subs = $byParent[(int)$cat['id']] ?? []; ?>
    <?php if (empty($subs)): ?>
      <div class="muted">No subforums yet.</div>
    <?php else: ?>
      <ul class="sublist">
        <?php foreach ($subs as $sf): if (!can_view_forum($sf)) continue; ?>
          <li>
            <a href="/forum/forum.php?id=<?= (int)$sf['id'] ?>"><?= e($sf['name']) ?></a>
            <?php if (!empty($sf['admin_only'])): ?><span class="pill">Staff</span><?php endif; ?>
          </li>
        <?php endforeach; ?>
      </ul>
    <?php endif; ?>
  </div>
<?php endforeach; ?>

<?php forum_footer(); ?>