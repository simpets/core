<?php
// /forum/_common.php
session_start();
require_once __DIR__ . '/../includes/db.php';

function current_user_id() { return $_SESSION['user_id'] ?? null; }
function current_username(){ return $_SESSION['username'] ?? null; }
function is_admin() {
  $g = strtolower($_SESSION['usergroup'] ?? '');
  return !empty($_SESSION['user_id']) && in_array($g, ['admin','admins']);
}
function require_member() {
  if (empty($_SESSION['user_id'])) {
    header('Location: /login.php?next=' . urlencode($_SERVER['REQUEST_URI']));
    exit;
  }
}

// CSRF
if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
function csrf_input(){ echo '<input type="hidden" name="csrf" value="'.htmlspecialchars($_SESSION['csrf']).'">'; }
function csrf_ok($t){ return isset($_SESSION['csrf']) && hash_equals($_SESSION['csrf'], (string)$t); }

// Escaping + mini formatting (allow simple [b], [i], [u], links, and line breaks)
function e($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
function format_post($text){
  $t = trim((string)$text);
  $t = e($t);
  $patterns = [
    '/\[b\](.*?)\[\/b\]/is' => '<strong>$1</strong>',
    '/\[i\](.*?)\[\/i\]/is' => '<em>$1</em>',
    '/\[u\](.*?)\[\/u\]/is' => '<u>$1</u>',
    '/\bhttps?:\/\/[^\s<]+/i' => '<a href="$0" target="_blank" rel="nofollow ugc noopener">$0</a>',
  ];
  foreach ($patterns as $re => $rep) $t = preg_replace($re, $rep, $t);
  return nl2br($t);
}

// Fetch a user display name
function user_display($pdo, $id){
  $st = $pdo->prepare("SELECT username, nickname FROM users WHERE id = ?");
  $st->execute([$id]);
  $u = $st->fetch();
  if (!$u) return "User#".$id;
  return $u['nickname'] ? $u['nickname'].' ('.$u['username'].')' : $u['username'];
}

// Layout helpers
function forum_header($title='Forum'){
  include __DIR__ . '/../menu.php';
  echo '<div class="container" style="max-width:1000px;margin:24px auto;">';
  echo '<h1>'.e($title).'</h1>';
}
function forum_footer(){
  echo '</div>';
  include __DIR__ . '/../footer.php';
}