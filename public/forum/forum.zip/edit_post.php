<?php
// /forum/edit_post.php — edit a post (owner/admin) with rich WYSIWYG, image URLs, and column-aware update
require_once __DIR__ . '/_common.php';
require_member();

/* ---------- tiny sanitizer (safe subset + IMG) ---------- */
if (!function_exists('sanitize_html_basic')) {
  function sanitize_html_basic(string $html): string {
    // allow a safe subset of tags/attrs (now includes <img>)
    $allowed = '<b><strong><i><em><u><p><br><ul><ol><li><a><blockquote><hr><code><pre><table><thead><tbody><tr><th><td><img>';
    $html = strip_tags($html, $allowed);

    // keep only http(s) links; force rel/target
    if (preg_match_all('#<a\s[^>]*href=("|\')(.*?)\1[^>]*>#i', $html, $m, PREG_SET_ORDER)) {
      foreach ($m as $a) {
        $full = $a[0]; $url = $a[2];
        if (!preg_match('#^https?://#i', $url)) {
          $html = str_replace($full, '', $html); // strip tag, keep text
        } else {
          // ensure rel/target; strip JS handlers
          $safe = preg_replace('/\s(on\w+)=("|\')[^"\']*\2/i', '', $full);
          if (!preg_match('/\brel=/i',   $safe)) $safe = preg_replace('#<a\s#i', '<a rel="nofollow noopener" ', $safe, 1);
          if (!preg_match('/\btarget=/i',$safe)) $safe = preg_replace('#<a\s#i', '<a target="_blank" ', $safe, 1);
          $html = str_replace($full, $safe, $html);
        }
      }
    }

    // validate <img> src (http/https only); remove JS handlers; add loading=lazy; keep alt/title/width/height only
    if (preg_match_all('#<img\s[^>]*src=("|\')(.*?)\1[^>]*>#i', $html, $m, PREG_SET_ORDER)) {
      foreach ($m as $img) {
        $full = $img[0]; $src = $img[2];
        if (!preg_match('#^https?://#i', $src)) {
          // disallow data: and other schemes to keep DB tidy & safe
          $html = str_replace($full, '', $html);
        } else {
          $safe = $full;
          // strip any on* handlers and style
          $safe = preg_replace('/\s(on\w+|style)=("|\')[^"\']*\2/i', '', $safe);
          // whitelist basic attributes: src, alt, title, width, height, loading
          // remove any other attributes
          // (quick approach: rebuild tag)
          $alt    = '';
          $title  = '';
          $width  = '';
          $height = '';
          if (preg_match('/\balt=("|\')(.*?)\1/i',   $full, $m2)) $alt = htmlspecialchars($m2[2], ENT_QUOTES|ENT_SUBSTITUTE, 'UTF-8');
          if (preg_match('/\btitle=("|\')(.*?)\1/i', $full, $m2)) $title = htmlspecialchars($m2[2], ENT_QUOTES|ENT_SUBSTITUTE, 'UTF-8');
          if (preg_match('/\bwidth=("|\')(\d{1,4})\1/i',  $full, $m2)) $width = (string)intval($m2[2], 10);
          if (preg_match('/\bheight=("|\')(\d{1,4})\1/i', $full, $m2)) $height = (string)intval($m2[2], 10);
          $attrs = ' src="'.htmlspecialchars($src, ENT_QUOTES|ENT_SUBSTITUTE, 'UTF-8').'" loading="lazy"';
          if ($alt    !== '') $attrs .= ' alt="'.$alt.'"';
          if ($title  !== '') $attrs .= ' title="'.$title.'"';
          if ($width  !== '') $attrs .= ' width="'.$width.'"';
          if ($height !== '') $attrs .= ' height="'.$height.'"';
          $rebuilt = '<img'.$attrs.'>';
          $html = str_replace($full, $rebuilt, $html);
        }
      }
    }

    // collapse empty paragraphs
    $html = preg_replace('#(<p>\s*</p>)+#i', '<p><br></p>', $html);

    return $html;
  }
}

/* ---------- schema helpers ---------- */
function table_cols(PDO $pdo, string $table): array {
  $cols = [];
  $q = $pdo->query("SHOW COLUMNS FROM {$table}");
  if ($q) foreach ($q->fetchAll(PDO::FETCH_ASSOC) as $r) $cols[strtolower($r['Field'])] = true;
  return $cols;
}
function has_col(array $cols, string $name): bool { return isset($cols[strtolower($name)]); }
function user_is_owner(int $ownerId): bool { return (int)($_SESSION['user_id'] ?? 0) === $ownerId; }

/* ---------- load post ---------- */
$post_id = (int)($_GET['id'] ?? 0);
if ($post_id <= 0) { http_response_code(400); exit('Invalid post id'); }

$pcols = table_cols($pdo,'posts');

$bodyCandidates   = ['body','content','message','post_text','text'];
$authorIdCols     = ['user_id','author_id','poster_id'];

/* Select ALL possible body columns so we can detect which one actually holds this post */
$select = ["p.id"];
if (has_col($pcols,'thread_id')) { $select[] = "p.thread_id"; }
elseif (has_col($pcols,'topic_id')) { $select[] = "p.topic_id AS thread_id"; }
foreach ($authorIdCols as $c) if (has_col($pcols,$c)) $select[] = "p.$c AS user_id";

$bodySelectMap = []; // alias => real column
foreach ($bodyCandidates as $c) {
  if (has_col($pcols,$c)) {
    $alias = "body__" . $c;
    $bodySelectMap[$alias] = $c;
    $select[] = "p.$c AS $alias";
  }
}

$selectList = implode(', ', $select);
$ps = $pdo->prepare("SELECT $selectList FROM posts p WHERE p.id = ?");
$ps->execute([$post_id]);
$post = $ps->fetch(PDO::FETCH_ASSOC);
if (!$post) { http_response_code(404); exit('Post not found'); }
$thread_id = (int)$post['thread_id'];
$ownerId   = (int)($post['user_id'] ?? 0);

/* Detect which body column this post is actually using: pick the first non-empty among the fetched aliases */
$currentHtml = '';
$bodyColUsed = null;
foreach ($bodySelectMap as $alias => $real) {
  if (isset($post[$alias]) && $post[$alias] !== null && $post[$alias] !== '') {
    $currentHtml = (string)$post[$alias];
    $bodyColUsed = $real;
    break;
  }
}
/* If all are empty, fall back to the first existing body column */
if (!$bodyColUsed) {
  foreach ($bodyCandidates as $c) {
    if (has_col($pcols,$c)) { $bodyColUsed = $c; break; }
  }
}
if (!$bodyColUsed) { http_response_code(500); exit('No editable text column found in posts table.'); }

/* ---------- permissions via thread/forum ---------- */
$st = $pdo->prepare("SELECT t.id, t.forum_id, t.is_locked, f.admin_only FROM threads t JOIN forums f ON f.id=t.forum_id WHERE t.id=?");
$st->execute([$thread_id]);
$thread = $st->fetch(PDO::FETCH_ASSOC);
if (!$thread) { http_response_code(404); exit('Thread not found'); }

require_forum_access($thread);
if (!is_admin() && !user_is_owner($ownerId)) { http_response_code(403); exit('You cannot edit this post.'); }
if (!empty($thread['is_locked']) && !is_admin()) { http_response_code(403); exit('Thread is locked.'); }

/* ---------- handle submit ---------- */
$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if (!csrf_ok($_POST['csrf'] ?? '')) {
    $errors[] = "Security token invalid. Please reload.";
  } else {
    $raw  = (string)($_POST['body'] ?? '');
    $html = sanitize_html_basic($raw);
    if (trim(strip_tags($html)) === '') $errors[] = "Message cannot be empty.";

    if (!$errors) {
      try {
        $sql = "UPDATE posts SET {$bodyColUsed} = ?";
        if (has_col($pcols,'updated_at')) $sql .= ", updated_at = NOW()";
        $sql .= " WHERE id = ?";

        $upd = $pdo->prepare($sql);
        $upd->execute([$html, $post_id]);

        header('Location: /forum/thread.php?id='.(int)$thread_id);
        exit;
      } catch (Throwable $e) {
        $errors[] = "Failed to edit post: " . $e->getMessage();
      }
    }
  }
}

forum_header('Edit Post');
?>
<style>
  .card{background:#fff;border:1px solid #ddd;border-radius:12px;padding:16px;margin:16px 0}
  .btn{display:inline-block;padding:8px 12px;border:1px solid #888;border-radius:8px;background:#f3f3f3;color:#111;text-decoration:none}
  .field{margin:8px 0}
  textarea#body{width:100%;min-height:320px;padding:10px;border:1px solid #ccc;border-radius:8px}
</style>

<div class="card" style="max-width:940px;">
  <?php foreach ($errors as $e): ?>
    <div style="color:#a33;margin-bottom:8px;"><?= e($e) ?></div>
  <?php endforeach; ?>

  <form method="post" autocomplete="off">
    <?php csrf_input(); ?>
    <div class="field">
      <label>Message</label>
      <!-- Pre-fill with current HTML, escaped for safety inside textarea -->
      <textarea id="body" name="body"><?= htmlspecialchars($currentHtml ?? '', ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8') ?></textarea>
    </div>
    <div class="field">
      <button class="btn" type="submit">Save</button>
      <a class="btn" href="/forum/thread.php?id=<?= (int)$thread_id ?>">Cancel</a>
    </div>
  </form>
</div>

<!-- TinyMCE (CDN) — richer toolbar + image URLs -->
<script src="https://cdn.jsdelivr.net/npm/tinymce@6/tinymce.min.js" referrerpolicy="origin"></script>
<script>
tinymce.init({
  selector: '#body',
  menubar: false,
  branding: false,
  plugins: 'autoresize link lists code table image',
  toolbar: 'undo redo | bold italic underline | bullist numlist | blockquote hr | link image | table | code | removeformat',
  default_link_target: '_blank',
  link_assume_external_targets: true,
  convert_urls: false,
  statusbar: false,
  autoresize_bottom_margin: 16,

  // Image embedding (URL-based only; uploads disabled)
  images_upload_handler: function (blobInfo, progress) {
    return Promise.reject('Image uploads are disabled; please use an http(s) image URL.');
  },
  automatic_uploads: false,
  paste_data_images: false, // blocks base64 blobs (keeps DB tidy)

  // Keep HTML simple; server sanitizer still runs
  valid_elements: 'p,br,strong/b,em/i,u,ul,ol,li,a[href|target|rel],blockquote,hr,code,pre,table,thead,tbody,tr,th,td,img[src|alt|title|width|height|loading]',
  content_style: 'body{font-family:system-ui,Segoe UI,Roboto,Helvetica,Arial,sans-serif;font-size:14px;line-height:1.5;} .tox .tox-statusbar{display:none;}'
});
</script>

<?php forum_footer(); ?>