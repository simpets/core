<?php
// /forum/reply.php — reply + fill ALL required legacy columns
require_once __DIR__ . '/_common.php';
require_member();

$thread_id = (int)($_GET['thread_id'] ?? 0);
if ($thread_id <= 0) { http_response_code(400); exit('Invalid thread'); }

$st = $pdo->prepare("SELECT t.id, t.forum_id, t.is_locked, f.admin_only FROM threads t JOIN forums f ON f.id = t.forum_id WHERE t.id = ?");
$st->execute([$thread_id]);
$thread = $st->fetch(PDO::FETCH_ASSOC);
if (!$thread) { http_response_code(404); exit('Thread not found'); }
require_forum_access($thread);
if (!empty($thread['is_locked'])) { http_response_code(403); exit('Thread is locked.'); }

function colmap(PDO $pdo, string $table): array {
  $out=[]; $q=$pdo->query("SHOW COLUMNS FROM {$table}");
  if ($q) foreach ($q->fetchAll(PDO::FETCH_ASSOC) as $r) $out[strtolower($r['Field'])]=$r;
  return $out;
}
function has(array $m,string $c):bool{ return isset($m[strtolower($c)]); }
function required(array $m,string $c):bool{
  $c=strtolower($c);
  return isset($m[$c]) && strtoupper((string)$m[$c]['Null'])==='NO' && $m[$c]['Default']===null;
}
function u_id():int{ return (int)($_SESSION['user_id'] ?? 0); }
function u_name():string{ return (string)($_SESSION['username'] ?? ''); }

$errors = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if (!csrf_ok($_POST['csrf'] ?? '')) {
    $errors[] = "Security token invalid. Please reload.";
  } else {
    $body = trim((string)($_POST['body'] ?? ''));
    
    
    $body = sanitize_html_basic($body);

    
    
    
    
    
    
    
    if ($body === '') $errors[] = "Message cannot be empty.";

    if (!$errors) {
      try {
        $pdo->beginTransaction();

        $pmap   = colmap($pdo,'posts');
        $cols   = [];
        $params = [];

        // Linkage
        if (has($pmap,'thread_id')) { $cols[]='thread_id'; $params[]=$thread_id; }
        if (has($pmap,'topic_id'))  { $cols[]='topic_id';  $params[]=$thread_id; }

        // User id variants (fill all required, else first available)
        $uid = u_id();
        foreach (['user_id','author_id','poster_id'] as $c) if (has($pmap,$c) && required($pmap,$c)) { $cols[]=$c; $params[]=$uid; }
        if (!array_intersect(['user_id','author_id','poster_id'], array_map('strtolower',$cols))) {
          foreach (['user_id','author_id','poster_id'] as $c) if (has($pmap,$c)) { $cols[]=$c; $params[]=$uid; break; }
        }

        // Author display
        $uname = u_name();
        $authorReq = false;
        foreach (['author','poster','username'] as $c) if (has($pmap,$c) && required($pmap,$c)) { $cols[]=$c; $params[]=$uname; $authorReq=true; }
        if (!$authorReq) { foreach (['author','poster','username'] as $c) if (has($pmap,$c)) { $cols[]=$c; $params[]=$uname; break; } }

        // Body/content — fill ALL required, else first available
        $bodyCols = ['body','content','message','post_text','text'];
        $bodyReq = false;
        foreach ($bodyCols as $c) if (has($pmap,$c) && required($pmap,$c)) { $cols[]=$c; $params[]=$body; $bodyReq=true; }
        if (!$bodyReq) { foreach ($bodyCols as $c) if (has($pmap,$c)) { $cols[]=$c; $params[]=$body; break; } }

        // Optional metadata
        $ip = $_SERVER['REMOTE_ADDR'] ?? '';
        if (has($pmap,'ip'))         { $cols[]='ip';         $params[]=$ip; }
        if (has($pmap,'ip_address')) { $cols[]='ip_address'; $params[]=$ip; }
        if (has($pmap,'user_agent')) { $cols[]='user_agent'; $params[]=(string)($_SERVER['HTTP_USER_AGENT'] ?? ''); }

        // Timestamps
        $nowCols = [];
        foreach (['created_at','post_time','posted_at','created'] as $ts) if (has($pmap,$ts)) $nowCols[]=$ts;

        $sqlCols = implode(',', $cols) . (empty($nowCols) ? '' : ',' . implode(',', $nowCols));
        $place   = rtrim(str_repeat('?,', count($params)), ',');
        $sqlVals = $place . (empty($nowCols) ? '' : ',' . implode(',', array_fill(0, count($nowCols), 'NOW()')));

        $ins = $pdo->prepare("INSERT INTO posts ($sqlCols) VALUES ($sqlVals)");
        $ins->execute($params);

        // touch thread last_post_at if exists
        $tmap = colmap($pdo,'threads');
        if (has($tmap,'last_post_at')) {
          $pdo->prepare("UPDATE threads SET last_post_at = NOW() WHERE id = ?")->execute([$thread_id]);
        }

        $pdo->commit();
        header('Location: /forum/thread.php?id=' . $thread_id);
        exit;
      } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        $errors[] = "Failed to post reply: " . $e->getMessage();
      }
    }
  }
}

forum_header('Reply');
?>
<style>
  .card{background:#fff;border:1px solid #ddd;border-radius:12px;padding:16px;margin:16px 0}
  .btn{display:inline-block;padding:8px 12px;border:1px solid #888;border-radius:8px;background:#f3f3f3;color:#111;text-decoration:none}
  .field{margin:8px 0}
  textarea{width:100%;min-height:180px;padding:10px;border:1px solid #ccc;border-radius:8px}
</style>

<div class="card" style="max-width:840px;">
  <?php foreach ($errors as $e): ?>
    <div style="color:#a33;margin-bottom:8px;"><?= e($e) ?></div>
  <?php endforeach; ?>

  <form method="post" autocomplete="off">
    <?php csrf_input(); ?>
    <div class="field">
      <label>Message</label>
      <textarea name="body" required></textarea>
    </div>
    <div class="field">
      <button class="btn" type="submit">Post Reply</button>
      <a class="btn" href="/forum/thread.php?id=<?= (int)$thread_id ?>">Cancel</a>
    </div>
  </form>
</div>

<?php forum_footer(); ?>